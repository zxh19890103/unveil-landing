/** built on 10:02:07 PM; */
import{a as N,b as k,c as A,d as C,e as b,g as R}from"../chunk-GVHAZSG7.js";import"../chunk-R3GHN6VW.js";import*as s from"three";import F from"react";import I from"react-dom/client";import*as j from"three";var w=k();var v=(r,e)=>{let t=w.project([r,e]);return new j.Vector3(t[0],t[1],0)};import{useState as y}from"react";import{jsx as l,jsxs as h}from"react/jsx-runtime";function H(r){let[e,t]=y(0),[o,a]=y(0),[i,d]=y(0),[u,f]=y(0);return h("div",{className:"fixed top-0 left-0 h-screen w-64 bg-slate-700/70 shadow-lg border-r border-cyan-400 p-4 text-white z-50 flex flex-col gap-4",children:[l("div",{className:"text-cyan-400 text-xl font-bold tracking-widest border-b border-cyan-600 pb-2",children:"\u2699\uFE0F MISSILE OPS"}),l("div",{className:"space-y-2 text-sm",children:h("div",{className:"flex justify-between",children:[l("span",{className:"text-gray-300",children:"\u570B\u5BB6\uFF1A"}),l("span",{className:"text-cyan-300 font-semibold",children:"\u4E2D\u570B vs \u65E5\u672C"})]})}),l("div",{className:"border-t border-cyan-700 mt-2"}),h("div",{className:"space-y-2 text-sm",children:[h("label",{className:"block",children:[l("span",{className:"text-gray-400",children:"A\u65B9 \u5766\u514B\u6578\u91CF"}),l("input",{type:"number",min:0,value:e,onChange:c=>t(parseInt(c.target.value)||0),className:"mt-1 w-full bg-gray-800 text-cyan-200 border border-cyan-600 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-cyan-400"})]}),h("label",{className:"block",children:[l("span",{className:"text-gray-400",children:"A\u65B9 \u8ECD\u8266\u6578\u91CF"}),l("input",{type:"number",min:0,value:o,onChange:c=>a(parseInt(c.target.value)||0),className:"mt-1 w-full bg-gray-800 text-cyan-200 border border-cyan-600 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-cyan-400"})]}),h("label",{className:"block",children:[l("span",{className:"text-gray-400",children:"B\u65B9 \u5766\u514B\u6578\u91CF"}),l("input",{type:"number",min:0,value:i,onChange:c=>d(parseInt(c.target.value)||0),className:"mt-1 w-full bg-gray-800 text-cyan-200 border border-cyan-600 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-cyan-400"})]}),h("label",{className:"block",children:[l("span",{className:"text-gray-400",children:"B\u65B9 \u8ECD\u8266\u6578\u91CF"}),l("input",{type:"number",min:0,value:u,onChange:c=>f(parseInt(c.target.value)||0),className:"mt-1 w-full bg-gray-800 text-cyan-200 border border-cyan-600 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-cyan-400"})]})]}),h("div",{className:"mt-4 space-y-2",children:[l("button",{className:"w-full bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-2 px-4 rounded-md shadow transition-all",children:"\u914D\u7F6E"}),l("button",{onClick:()=>{console.log("A\u65B9 \u5766\u514B\uFF1A",e),console.log("A\u65B9 \u8ECD\u8266\uFF1A",o),console.log("B\u65B9 \u5766\u514B\uFF1A",i),console.log("B\u65B9 \u8ECD\u8266\uFF1A",u),r.onSetup({atanks:e,aships:o,btanks:i,bships:u})},className:"w-full bg-gray-700 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md border border-cyan-500 transition-all",children:"\u958B\u59CB\u63A8\u6F14"})]}),l("div",{className:"mt-auto text-xs text-gray-400 text-center border-t border-cyan-800 pt-2",children:"SYSTEM READY v1.1"})]})}import*as n from"three";import{BufferGeometry as O,ShaderMaterial as U,AdditiveBlending as z}from"three";var E=class extends n.Object3D{constructor(t,o,a=3){super();this.from=t;this.to=o;this.t=0;this.opacity=.55;this.length=0;this.phase=1;this.speed=a;let i=t.distanceTo(o)*Math.tan(60*n.MathUtils.DEG2RAD),d=this.computeControlPoint(t,o,i);this.curve=new n.QuadraticBezierCurve3(t,d,o),this.length=this.curve.getLength();let u=R(this.curve,0,1),f=new n.TubeGeometry(u,300,.1,5,!1),p=new n.Mesh(f,new n.MeshBasicMaterial({transparent:!0,opacity:this.opacity,color:16755200}));this.tail=p,this.add(p)}computeControlPoint(t,o,a=20){let i=t.clone().lerp(o,.5);return i.y+=a,i}update(t){switch(this.phase){case 1:{this.t+=t*this.speed/this.length,this.t=n.MathUtils.clamp(this.t,0,1);let o=R(this.curve,0,this.t);this.tail.geometry.dispose();let a=new n.TubeGeometry(o,300,.1,5,!1);this.tail.geometry=a,this.t>=1&&(this.explosion=new M(500),this.curve.getPointAt(1,this.explosion.position),this.add(this.explosion),b.bomb.play(),this.phase=2);break}case 2:{if(!this.explosion.update(t)){this.phase=3;break}this.opacity-=.003,this.opacity>0&&(this.tail.material.opacity=this.opacity,this.tail.material.needsUpdate=!0);break}case 3:{this.removeFromParent(),this.dispose(),console.log("end!");break}}}dispose(){this.tail.geometry.dispose(),this.tail.material.dispose(),this.explosion?.dispose()}},M=class extends n.Points{constructor(t=200,o=1,a=5){let i=new O,d=new Float32Array(t*3),u=new Float32Array(t*3);for(let p=0;p<t;p++){let c=p*3;d[c]=0,d[c+1]=0,d[c+2]=0;let g=new n.Vector3(Math.random()*2-1,Math.random()*2-1,Math.random()*2-1).setLength(a);u[c]=g.x,u[c+1]=g.y,u[c+2]=g.z}i.setAttribute("position",new n.BufferAttribute(d,3)),i.setAttribute("velocity",new n.BufferAttribute(u,3));let f=new U({transparent:!0,blending:z,depthWrite:!1,uniforms:{u_time:{value:0},u_dur:{value:o}},vertexShader:`
      attribute vec3 direction;
      attribute vec3 velocity;

      uniform float u_dur;
      uniform float u_time;

        void main() {
          vec3 newPosition = position + velocity * u_time;
          gl_PointSize = 10.0;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
        }
      `,fragmentShader:`
        uniform float u_dur;
        uniform float u_time;

        void main() {
          float dist = length(gl_PointCoord - vec2(0.5));
          float alpha = 1.0 - u_time / u_dur;
          gl_FragColor = vec4(1.0, 0.6, 0.2, alpha);
        }
      `});super(i,f);this.duration=o;this.speed=a;this.elapsed=0}dispose(){this.geometry.dispose(),this.material.dispose()}update(t){if(this.elapsed+=t*.2,this.elapsed>=this.duration)return!1;let o=this.geometry.attributes.velocity;for(let a=0;a<o.count;a+=1)o[a*3+1]-=3*t;return o.needsUpdate=!0,this.material.uniforms.u_time.value=this.elapsed,!0}};import{gsap as q}from"gsap";var B=document.querySelector("#threejs-container"),m=new N(B);m.setupControls();var G=m.createWorld(),{camera:x,scene:T}=m;x.position.set(0,-18,10);x.lookAt(0,0,0);x.add(b.audioLis);m.addCSS2DRenderer();var _=new s.DirectionalLight(16777215,2);_.position.set(0,1e3,0);T.add(_,_.target);var W=new s.AmbientLight(16777215,.5);T.add(W);var S=()=>{K.render(G,x)};m.addEventListener("viewportResize",()=>{S()});m.controls.addEventListener("change",()=>{S()});function $(r){let e=0;for(let o=0;o<r.length;o++)e=r.charCodeAt(o)+((e<<5)-e);return`hsl(${e%360}, 70%, 60%)`}var J=new s.LineBasicMaterial({color:3878422});function Q(r,e){let t=e.map(c=>{let g=w.project(c);return new s.Vector2(g[0],g[1])}),o=$(r),a=new s.Color(o),i=new s.ShapeGeometry(new s.Shape(t)),d=new s.ShaderMaterial({vertexShader:`
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,fragmentShader:`
    // uniform vec3 uColor;
    varying vec2 vUv;

    // GLSL 2D noise \u51FD\u6578\uFF08\u4F60\u53EF\u4EE5\u5167\u5D4C\u9032 shader \u4E2D\uFF09
    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      vec2 u = f*f*(3.0-2.0*f);
      return mix(
        mix(hash(i + vec2(0.0,0.0)), hash(i + vec2(1.0,0.0)), u.x),
        mix(hash(i + vec2(0.0,1.0)), hash(i + vec2(1.0,1.0)), u.x),
        u.y);
    }

    float fakeHeight(vec2 uv) {
      float h = sin(uv.x * 10.0) * cos(uv.y * 10.0);
      return h;
    }

    void main() {
      float h = noise(vUv * 60.0);
      // float h = fakeHeight(vUv);
      vec3 baseColor = mix(vec3(${a.toArray().join(",")}), vec3(0.8, 0.8, 0.6), h * 0.5 + 0.5);
      gl_FragColor = vec4(baseColor, 1);
    }
  `,side:s.DoubleSide}),u=new s.Mesh(i,d),f=new s.EdgesGeometry(i),p=new s.LineSegments(f,J);G.add(u,p)}function L(r){return fetch(`./data/${r}.json`).then(e=>e.json()).then(e=>{e.features.forEach(t=>{let o=t.geometry;if(o.type==="MultiPolygon"){let a=o.coordinates;for(let i of a)Q(t.properties.NL_NAME_1,i[0])}else console.log(o.type,o)})},e=>{console.log(e)}).catch(e=>{console.log(e)})}var P=[];function Y(r){let e=new E(this.position.clone(),v(...r));T.add(e),P.push(e)}Promise.all([L("gadm41_CHN_1"),L("gadm41_JPN_1"),L("gadm41_TWN_1")]).then(()=>{S()});var K=m.addWebGLRenderer("tile",B,{animated:!1,antialias:!0,zIndex:1});function X(r){let e=v(...r),t=this.position,o=e.x-t.x,a=e.y-t.y,i=q.timeline(),d=Math.sqrt(o*o+a*a),u=Math.atan2(a,o);i.to(this.rotation,{z:u,duration:2})}var V=[],D=(r,e)=>{r.forEach((t,o)=>{let a=new C(A.quickdemo_military_data_t_90sm_main_battle_tank_glb,"./data/tank.png","grey",{scaleFactor:.3,rotation:[1,-1,0]});a.position.copy(v(t[2],t[1])),V.push(a),T.add(a),a.shootTarget=e,X.call(a,e)}),m.onAnimate((t,o)=>{for(let a of P)a.update(t)})},Z=[116.4074,39.9042],ee=[136.7567,35.4875];D([["\u6B66\u6F22",30.545,114.342],["\u897F\u85CF",31.91,89.15],["\u65B0\u7586",42,86],["\u9752\u6D77",35.5,96.8],["\u798F\u5EFA",26.2,117.8]],ee);D([["japan",35.4875,136.7567]],Z);m.startAnimation();I.createRoot(document.querySelector(".App"),{}).render(F.createElement(H,{onSetup:r=>{V.forEach(e=>{Y.call(e,e.shootTarget)})}}));
